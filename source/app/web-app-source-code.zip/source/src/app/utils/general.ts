export const classnames = (...args: any) => {
  return args.join(' ');
};
