# How to run?
1. yarn dev
2. Send post request to localhost:3001/api/gen-comment to generate comment for a specific code script