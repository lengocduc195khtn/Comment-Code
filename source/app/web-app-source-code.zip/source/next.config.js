/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: false, // true
  // headers: [
  //   {
  //     key: 'Cache-Control',
  //     value: 'no-store',
  //   },
  // ],
  // assetPrefxix: ['/src/app/assets/', '/src/main-board/assets/'] // assetPrefix requires the trailing slash
};
